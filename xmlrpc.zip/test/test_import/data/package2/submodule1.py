import sys
sys.modules.pop(__package__, None)
from . import submodule2
